Assignment 3 submission package

Start with Assignment3_Kadyrkhan_Tynysbek_Corrected.docx.

Reproduce the analysis (Python 3.10+, standard library only):
1. Extract this ZIP into a writable directory.
2. Open a terminal in the extracted folder.
3. Run: python analyze_datasets.py
4. Run tests: python -m unittest -v test_analyze_datasets

Input: sources/source_observations.json, manually extracted from official publication descriptions on 2026-10-20.
Field definitions: DATA_DICTIONARY.md.
Selection decisions: screening_log.csv.
Prepared data: dataset_inventory.csv.
Results: analysis_output.json, task_summary.csv and task_modality_summary.csv.
Recorded execution environment: environment.json.
Test evidence: test_analyze_datasets.py and TEST_RESULTS.txt.

Expected output: 7 resources, 6 task categories, 2 LLM-evaluation resources.
This is an analysis of publication metadata, not corpus contents or model performance. Unknown licence means not established by this inspection. Dataset versions, corpus quality and reuse conditions require further verification. Synthetic test mutations are software checks only, not research observations.
